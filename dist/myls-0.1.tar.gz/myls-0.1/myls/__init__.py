from myls import ls
from myls import main

print 'Importing myls'
