#!/usr/bin/env python

from distutils.core import setup


setup(
      name='myls',
      version='0.1',
      author='T. Le Blanc',
      packages=['myls'],
      scripts=['scripts/myls']
)
